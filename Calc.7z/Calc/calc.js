let valorPrev = "";
let valorNuevo = ""; 
let valorResul = "";
let operacionMat = "";
let clickDecimal = false;
let valorMS = "";
 
function numeroPresionado(num){
    if(valorResul){
        valorNuevo = num;
        valorResul = "";
    } else {
        if(num === '.'){
            if(clickDecimal != true){
                valorNuevo += num;
                clickDecimal = true;
            }
        } else {
            valorNuevo += num;
        }
    }
    document.getElementById("entry").value = valorNuevo;
}
 
function operPresionada(operacion){
    if(!valorResul){
        valorPrev = valorNuevo;
    } else {
        valorPrev = valorResul;
    }
    valorNuevo = "";
    clickDecimal = false;
    operacionMat = operacion;
    valorResul = "";
    document.getElementById("entry").value = "";
}
 
function igualPresionado(){
    clickDecimal = false;
    valorPrev = parseFloat(valorPrev);
    valorNuevo = parseFloat(valorNuevo);
    switch(operacionMat){
        case "+":
            valorResul = valorPrev + valorNuevo;
            break;
        case "-":
            valorResul = valorPrev - valorNuevo;
            break;
        case "*":
            valorResul = valorPrev * valorNuevo;
            break;
        case "/":
            valorResul = valorPrev / valorNuevo;
            break;
        default:
            valorResul = valorNuevo;
    }
    valorPrev = valorResul;
    document.getElementById("entry").value = valorResul;
}
 
function clearButPress(){
    valorPrev = "";
    valorNuevo = "";
    valorResul = "";
    operacionMat = "";
    clickDecimal = false;
    document.getElementById("entry").value = "0";
}
 
function copyButPress(){
    valorMS = document.getElementById("entry").value;
}
